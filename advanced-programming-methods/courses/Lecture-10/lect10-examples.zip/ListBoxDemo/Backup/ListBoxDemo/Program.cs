using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace ListBoxDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Application.Run(new LBDemo());
        }
    }
}
