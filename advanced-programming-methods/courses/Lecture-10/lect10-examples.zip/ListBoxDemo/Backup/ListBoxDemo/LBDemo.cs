using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ListBoxDemo
{
    public partial class LBDemo : Form
    {
        public LBDemo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LBDemo_Load(object sender, EventArgs e)
        {
            for(int i = 0; i < 50; i++)
            {
                listBox1.Items.Add("Item " + i.ToString());
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            StringBuilder buf = new StringBuilder(50);
            if (listBox1.SelectionMode == SelectionMode.One)
            {
                buf.Append(listBox1.SelectedItem.ToString());
            }
            else
            {
                foreach (object o in listBox1.SelectedItems)
                {
                    buf.Append(o.ToString());
                    buf.Append(" ");
                }
            }
            label1.Text = buf.ToString();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                listBox1.SelectionMode = SelectionMode.MultiExtended;
            else
                listBox1.SelectionMode = SelectionMode.One;
        }
    }
}