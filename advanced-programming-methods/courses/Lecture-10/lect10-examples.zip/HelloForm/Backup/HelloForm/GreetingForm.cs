using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace HelloForm
{
    public class GreetingForm : Form
    {
        Label   greetingLabel;
        Button  cancelButton;

        public GreetingForm()
        {
            InitializeComponent();
        }

        void InitializeComponent()
        {
            greetingLabel = new Label();
            cancelButton = new Button();

            this.Text = "Hello, World";

            greetingLabel.Location = new Point(16, 24);
            greetingLabel.Text = "Hello, World";
            greetingLabel.Size = new Size(216, 24);
            greetingLabel.ForeColor = Color.Black;

            cancelButton.Location = new Point(150, 200);
            cancelButton.Size = new Size(112, 32);
            cancelButton.Text = "&Cancel";
            cancelButton.Click += new EventHandler(cancelButton_Click);

            //this.AutoScaleBaseSize = new Size(5, 13);
            this.AutoScaleDimensions = new SizeF(95.0f, 95.0f);
            this.ClientSize = new Size(300, 300);
            this.Controls.Add(cancelButton);
            this.Controls.Add(greetingLabel);
        }

        protected void cancelButton_Click(
            object sender, EventArgs e)
        {
            Application.Exit();
        }        
    }
}