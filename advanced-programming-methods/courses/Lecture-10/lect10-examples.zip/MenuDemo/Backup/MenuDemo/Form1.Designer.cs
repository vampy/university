namespace MenuDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.actionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goHomeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aSandwichToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.broccoliToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selLabel = new System.Windows.Forms.Label();
            this.pedanticToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.actionToolStripMenuItem,
            this.dayToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(292, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // actionToolStripMenuItem
            // 
            this.actionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.goHomeToolStripMenuItem,
            this.eatToolStripMenuItem,
            this.pedanticToolStripMenuItem});
            this.actionToolStripMenuItem.Name = "actionToolStripMenuItem";
            this.actionToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.actionToolStripMenuItem.Text = "Action";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // goHomeToolStripMenuItem
            // 
            this.goHomeToolStripMenuItem.Name = "goHomeToolStripMenuItem";
            this.goHomeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.goHomeToolStripMenuItem.Text = "Go &Home";
            this.goHomeToolStripMenuItem.Click += new System.EventHandler(this.goHomeToolStripMenuItem_Click);
            // 
            // eatToolStripMenuItem
            // 
            this.eatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aSandwichToolStripMenuItem,
            this.broccoliToolStripMenuItem});
            this.eatToolStripMenuItem.Name = "eatToolStripMenuItem";
            this.eatToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.eatToolStripMenuItem.Text = "&Eat";
            // 
            // aSandwichToolStripMenuItem
            // 
            this.aSandwichToolStripMenuItem.Name = "aSandwichToolStripMenuItem";
            this.aSandwichToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.aSandwichToolStripMenuItem.Text = "A &Sandwich";
            this.aSandwichToolStripMenuItem.Click += new System.EventHandler(this.aSandwichToolStripMenuItem_Click);
            // 
            // broccoliToolStripMenuItem
            // 
            this.broccoliToolStripMenuItem.Name = "broccoliToolStripMenuItem";
            this.broccoliToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.broccoliToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.broccoliToolStripMenuItem.Text = "&Broccoli";
            this.broccoliToolStripMenuItem.Click += new System.EventHandler(this.broccoliToolStripMenuItem_Click);
            // 
            // selLabel
            // 
            this.selLabel.AutoSize = true;
            this.selLabel.Location = new System.Drawing.Point(18, 177);
            this.selLabel.Name = "selLabel";
            this.selLabel.Size = new System.Drawing.Size(0, 13);
            this.selLabel.TabIndex = 1;
            // 
            // pedanticToolStripMenuItem
            // 
            this.pedanticToolStripMenuItem.Checked = true;
            this.pedanticToolStripMenuItem.CheckOnClick = true;
            this.pedanticToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.pedanticToolStripMenuItem.Name = "pedanticToolStripMenuItem";
            this.pedanticToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.pedanticToolStripMenuItem.Text = "Pedantic";
            this.pedanticToolStripMenuItem.Click += new System.EventHandler(this.pedanticToolStripMenuItem_Click);
            // 
            // dayToolStripMenuItem
            // 
            this.dayToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBox1});
            this.dayToolStripMenuItem.Name = "dayToolStripMenuItem";
            this.dayToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.dayToolStripMenuItem.Text = "Day";
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.Items.AddRange(new object[] {
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday"});
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 21);
            this.toolStripComboBox1.Click += new System.EventHandler(this.toolStripComboBox1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 266);
            this.Controls.Add(this.selLabel);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem actionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goHomeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aSandwichToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem broccoliToolStripMenuItem;
        private System.Windows.Forms.Label selLabel;
        private System.Windows.Forms.ToolStripMenuItem pedanticToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dayToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
    }
}

