using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MenuDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void quitBut_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void goHomeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            selLabel.Text = "Going home...";
        }

        private void aSandwichToolStripMenuItem_Click(object sender, EventArgs e)
        {
            selLabel.Text = "That's a good sandwich";
        }

        private void broccoliToolStripMenuItem_Click(object sender, EventArgs e)
        {
            selLabel.Text = "I love broccoli!";
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {
            if(toolStripComboBox1.SelectedItem != null)
                selLabel.Text = toolStripComboBox1.SelectedItem.ToString();
        }

        private void pedanticToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(pedanticToolStripMenuItem.CheckState == CheckState.Checked)
                selLabel.Text = "I am pedantic!";
            else
                selLabel.Text = "I am NOT pedantic!";
        }
    }
}