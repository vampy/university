using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TextBoxDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void quitBut_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void rightBut_CheckedChanged(object sender, EventArgs e)
        {
            textArea.TextAlign = HorizontalAlignment.Right;
        }

        private void centerBut_CheckedChanged(object sender, EventArgs e)
        {
            textArea.TextAlign = HorizontalAlignment.Center;
        }

        private void leftRadio_CheckedChanged(object sender, EventArgs e)
        {
            textArea.TextAlign = HorizontalAlignment.Left;
        }

        private void selectBut_Click(object sender, EventArgs e)
        {
            selectBox.Text = textArea.SelectedText;
        }
    }
}