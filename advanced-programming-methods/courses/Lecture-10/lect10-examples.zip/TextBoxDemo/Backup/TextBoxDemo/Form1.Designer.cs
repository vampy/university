namespace TextBoxDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textArea = new System.Windows.Forms.TextBox();
            this.selectBut = new System.Windows.Forms.Button();
            this.selectBox = new System.Windows.Forms.TextBox();
            this.alignGroup = new System.Windows.Forms.GroupBox();
            this.leftRadio = new System.Windows.Forms.RadioButton();
            this.centerBut = new System.Windows.Forms.RadioButton();
            this.rightBut = new System.Windows.Forms.RadioButton();
            this.quitBut = new System.Windows.Forms.Button();
            this.alignGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // textArea
            // 
            this.textArea.Location = new System.Drawing.Point(6, 6);
            this.textArea.Multiline = true;
            this.textArea.Name = "textArea";
            this.textArea.Size = new System.Drawing.Size(278, 85);
            this.textArea.TabIndex = 0;
            // 
            // selectBut
            // 
            this.selectBut.Location = new System.Drawing.Point(8, 105);
            this.selectBut.Name = "selectBut";
            this.selectBut.Size = new System.Drawing.Size(106, 21);
            this.selectBut.TabIndex = 1;
            this.selectBut.Text = "Get Selection";
            this.selectBut.UseVisualStyleBackColor = true;
            this.selectBut.Click += new System.EventHandler(this.selectBut_Click);
            // 
            // selectBox
            // 
            this.selectBox.Enabled = false;
            this.selectBox.Location = new System.Drawing.Point(8, 140);
            this.selectBox.Name = "selectBox";
            this.selectBox.Size = new System.Drawing.Size(275, 20);
            this.selectBox.TabIndex = 2;
            // 
            // alignGroup
            // 
            this.alignGroup.Controls.Add(this.rightBut);
            this.alignGroup.Controls.Add(this.centerBut);
            this.alignGroup.Controls.Add(this.leftRadio);
            this.alignGroup.Location = new System.Drawing.Point(10, 172);
            this.alignGroup.Name = "alignGroup";
            this.alignGroup.Size = new System.Drawing.Size(272, 48);
            this.alignGroup.TabIndex = 3;
            this.alignGroup.TabStop = false;
            this.alignGroup.Text = "Alignment";
            // 
            // leftRadio
            // 
            this.leftRadio.AutoSize = true;
            this.leftRadio.Location = new System.Drawing.Point(20, 19);
            this.leftRadio.Name = "leftRadio";
            this.leftRadio.Size = new System.Drawing.Size(43, 17);
            this.leftRadio.TabIndex = 0;
            this.leftRadio.TabStop = true;
            this.leftRadio.Text = "Left";
            this.leftRadio.UseVisualStyleBackColor = true;
            this.leftRadio.CheckedChanged += new System.EventHandler(this.leftRadio_CheckedChanged);
            // 
            // centerBut
            // 
            this.centerBut.AutoSize = true;
            this.centerBut.Location = new System.Drawing.Point(91, 19);
            this.centerBut.Name = "centerBut";
            this.centerBut.Size = new System.Drawing.Size(56, 17);
            this.centerBut.TabIndex = 1;
            this.centerBut.TabStop = true;
            this.centerBut.Text = "Center";
            this.centerBut.UseVisualStyleBackColor = true;
            this.centerBut.CheckedChanged += new System.EventHandler(this.centerBut_CheckedChanged);
            // 
            // rightBut
            // 
            this.rightBut.AutoSize = true;
            this.rightBut.Location = new System.Drawing.Point(180, 21);
            this.rightBut.Name = "rightBut";
            this.rightBut.Size = new System.Drawing.Size(50, 17);
            this.rightBut.TabIndex = 2;
            this.rightBut.TabStop = true;
            this.rightBut.Text = "Right";
            this.rightBut.UseVisualStyleBackColor = true;
            this.rightBut.CheckedChanged += new System.EventHandler(this.rightBut_CheckedChanged);
            // 
            // quitBut
            // 
            this.quitBut.Location = new System.Drawing.Point(90, 238);
            this.quitBut.Name = "quitBut";
            this.quitBut.Size = new System.Drawing.Size(100, 20);
            this.quitBut.TabIndex = 4;
            this.quitBut.Text = "Quit";
            this.quitBut.UseVisualStyleBackColor = true;
            this.quitBut.Click += new System.EventHandler(this.quitBut_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 266);
            this.Controls.Add(this.quitBut);
            this.Controls.Add(this.alignGroup);
            this.Controls.Add(this.selectBox);
            this.Controls.Add(this.selectBut);
            this.Controls.Add(this.textArea);
            this.Name = "Form1";
            this.Text = "Text Demo";
            this.alignGroup.ResumeLayout(false);
            this.alignGroup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textArea;
        private System.Windows.Forms.Button selectBut;
        private System.Windows.Forms.TextBox selectBox;
        private System.Windows.Forms.GroupBox alignGroup;
        private System.Windows.Forms.RadioButton rightBut;
        private System.Windows.Forms.RadioButton centerBut;
        private System.Windows.Forms.RadioButton leftRadio;
        private System.Windows.Forms.Button quitBut;
    }
}

