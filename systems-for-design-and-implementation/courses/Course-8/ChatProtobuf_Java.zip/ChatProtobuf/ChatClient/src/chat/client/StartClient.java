package chat.client;

import chat.protocol.protobuf.ProtoChatProxy;
import chat.services.IChatServer;
import chat.client.gui.ChatClientCtrl;
import chat.client.gui.ChatWindow;
import chat.client.gui.LoginWindow;
import chat.network.server.ChatServerProxy;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Mar 18, 2009
 * Time: 3:24:40 PM
 */
public class StartClient {
    public static void main(String[] args) {
        //IChatServer server=new ChatServerProxy("localhost", 55555);
        IChatServer server=new ProtoChatProxy("localhost", 55555);
        ChatClientCtrl ctrl=new ChatClientCtrl(server);


        LoginWindow logWin=new LoginWindow("Chat XYZ", ctrl);
        logWin.setSize(200,200);
        logWin.setLocation(150,150);
        logWin.setVisible(true);

    }
}
