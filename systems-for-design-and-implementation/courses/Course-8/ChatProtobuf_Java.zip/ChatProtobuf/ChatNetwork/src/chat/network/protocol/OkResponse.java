package chat.network.protocol;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Mar 18, 2009
 * Time: 4:29:54 PM
 */
public class OkResponse implements Response{
}
