package chat.network.protocol;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Mar 18, 2009
 * Time: 4:18:05 PM
 */
public interface Request extends Serializable{
}
