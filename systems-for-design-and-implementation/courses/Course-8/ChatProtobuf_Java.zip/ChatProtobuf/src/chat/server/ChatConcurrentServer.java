package chat.server;


import chat.services.IChatServer;
import chat.network.client.ChatClientWorker;

import java.net.Socket;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Mar 18, 2009
 * Time: 12:17:49 PM
 */
public class ChatConcurrentServer extends AbsConcurrentServer {
    private IChatServer chatServer;
    public ChatConcurrentServer(int port, IChatServer chatServer) {
        super(port);
        this.chatServer = chatServer;
        System.out.println("Chat- ChatConcurrentServer");
    }

    @Override
    protected Thread createWorker(Socket client) {
        ChatClientWorker worker=new ChatClientWorker(chatServer, client);
        Thread tw=new Thread(worker);
        return tw;
    }


}
