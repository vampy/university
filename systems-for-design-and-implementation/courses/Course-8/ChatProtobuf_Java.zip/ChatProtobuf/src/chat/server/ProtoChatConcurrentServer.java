package chat.server;

import chat.network.client.ChatClientWorker;
import chat.protocol.protobuf.ProtoChatWorker;
import chat.services.IChatServer;

import java.net.Socket;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: 4/21/14
 * Time: 1:15 AM
 */
public class ProtoChatConcurrentServer extends AbsConcurrentServer {
    private IChatServer chatServer;
        public ProtoChatConcurrentServer(int port, IChatServer chatServer) {
            super(port);
            this.chatServer = chatServer;
            System.out.println("Chat- ProtoChatConcurrentServer");
        }

        @Override
        protected Thread createWorker(Socket client) {
            ProtoChatWorker worker=new ProtoChatWorker(chatServer, client);
            Thread tw=new Thread(worker);
            return tw;
        }
}
