
import chat.persistence.repository.UserRepository;
import chat.persistence.repository.mock.UserRepositoryMock;
import chat.services.IChatServices;
import chat.server.ChatServerImpl;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Mar 25, 2009
 * Time: 8:14:02 PM
 */
public class StartServer {
    public static void main(String[] args) {
        UserRepository repo=new UserRepositoryMock();
        IChatServices chatServerImpl=new ChatServerImpl(repo);

        /*if (System.getSecurityManager() == null) {
            System.setSecurityManager(new SecurityManager());
        }*/
        try {
            String name = "Chat";
            IChatServices stub =(IChatServices) UnicastRemoteObject.exportObject(chatServerImpl, 0);
            Registry registry = LocateRegistry.getRegistry();
            registry.rebind(name, stub);
            System.out.println("Chat server   bound");
        } catch (Exception e) {
            System.err.println("Chat server exception:"+e);
            e.printStackTrace();
        }

    }

}
