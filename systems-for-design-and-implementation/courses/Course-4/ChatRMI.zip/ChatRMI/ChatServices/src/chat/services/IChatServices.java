package chat.services;

import chat.model.User;
import chat.model.Message;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Mar 18, 2009
 * Time: 1:32:07 PM
 */
public interface IChatServices extends Remote {
    public void login(User user, IObserverServices client) throws ChatException, RemoteException;
    public void sendMessage(Message message) throws ChatException,  RemoteException;
    public void logout(User user, IObserverServices client) throws ChatException,  RemoteException;
    public User[] getLoggedFriends(User user) throws ChatException,  RemoteException;
}
