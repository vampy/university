package chat.persistence.repository.mock;

import chat.persistence.Persistence;
import chat.persistence.repository.UserRepository;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Apr 1, 2009
 * Time: 10:09:47 PM
 */
public class MockPersistence extends Persistence{
    public UserRepository createUserRepository() {
        System.out.println("Mock repository created ");
        return new UserRepositoryMock();  
    }
}
