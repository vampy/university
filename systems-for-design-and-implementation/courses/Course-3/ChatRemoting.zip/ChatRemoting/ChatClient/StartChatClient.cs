﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms;
using chat.services;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using Hashtable=System.Collections.Hashtable;


namespace chat.client
{
    static class StartChatClient
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
           
            //IChatServer server=new ChatServerMock();          
           /* IChatServer server = new ChatServerProxy("127.0.0.1", 55555);
            ChatClientCtrl ctrl=new ChatClientCtrl(server);
            LoginWindow win=new LoginWindow(ctrl);
            Application.Run(win);*/
			BinaryServerFormatterSinkProvider serverProv = new BinaryServerFormatterSinkProvider();
			serverProv.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;
			BinaryClientFormatterSinkProvider clientProv = new BinaryClientFormatterSinkProvider();
			IDictionary props = new Hashtable();

			props["port"] = 0;
			TcpChannel channel = new TcpChannel(props, clientProv, serverProv);
			ChannelServices.RegisterChannel(channel, false);
			IChatServer server =
				(IChatServer)Activator.GetObject(typeof(IChatServer), "tcp://localhost:55555/Chat");

			ChatClientCtrl ctrl=new ChatClientCtrl(server);
			LoginWindow win=new LoginWindow(ctrl);
			Application.Run(win);
        }
    }
}
