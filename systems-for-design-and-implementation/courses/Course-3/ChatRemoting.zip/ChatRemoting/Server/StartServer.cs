﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;

using System.Text;
using System.Threading;
using chat.persistence.repository;
using chat.persistence.repository.mock;
using chat.persistence;
using chat.services;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

namespace chat
{
    using server;
    class StartServer
    {
        static void Main(string[] args)
        {
            
           /* IUserRepository userRepo = new UserRepositoryMock();
            IChatServer serviceImpl = new ChatServerImpl(userRepo);

            //IChatServer serviceImpl = new ChatServerImpl();
			SerialChatServer server = new SerialChatServer("127.0.0.1", 55555, serviceImpl);
            server.Start();
            Console.WriteLine("Server started ...");
            //Console.WriteLine("Press <enter> to exit...");
            Console.ReadLine();*/


			BinaryServerFormatterSinkProvider serverProv = new BinaryServerFormatterSinkProvider();
			serverProv.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;
			BinaryClientFormatterSinkProvider clientProv = new BinaryClientFormatterSinkProvider();
			IDictionary props = new Hashtable();

			props["port"] = 55555;
			TcpChannel channel = new TcpChannel(props, clientProv, serverProv);
			ChannelServices.RegisterChannel(channel, false);

			IUserRepository userRepo = new UserRepositoryMock();
			var server = new ChatServerImpl(userRepo);
			//var server = new ChatServerImpl();
			RemotingServices.Marshal(server, "Chat");
			//RemotingConfiguration.RegisterWellKnownServiceType(typeof(ChatServerImpl), "Chat",
			//    WellKnownObjectMode.Singleton);

			// the server will keep running until keypress.
			Console.WriteLine("Server started ...");
			Console.WriteLine("Press <enter> to exit...");
			Console.ReadLine();
            
        }
    }
		
    
}
