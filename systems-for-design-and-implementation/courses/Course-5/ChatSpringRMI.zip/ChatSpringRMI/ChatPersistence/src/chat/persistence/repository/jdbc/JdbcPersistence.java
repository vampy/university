package chat.persistence.repository.jdbc;

import chat.persistence.Persistence;
import chat.persistence.repository.UserRepository;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Apr 15, 2009
 * Time: 2:25:20 PM
 */
public class JdbcPersistence extends Persistence{
    public UserRepository createUserRepository() {
        System.out.println("JdbcPersistence");
        return new UserRepositoryJdbc();
    }
}
