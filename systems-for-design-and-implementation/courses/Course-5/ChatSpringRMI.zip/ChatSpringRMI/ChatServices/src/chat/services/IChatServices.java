package chat.services;

import chat.model.User;
import chat.model.Message;



/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Mar 18, 2009
 * Time: 1:32:07 PM
 */
public interface IChatServices{
     void login(User user, IObserverServices client) throws ChatException;
     void sendMessage(Message message) throws ChatException;
     void logout(User user, IObserverServices client) throws ChatException;
     User[] getLoggedFriends(User user) throws ChatException;
}
