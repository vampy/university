package chat.services;

import chat.model.Message;
import chat.model.User;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Mar 18, 2009
 * Time: 1:35:30 PM
 */
public interface IObserverServices extends Remote {
     void messageReceived(Message message) throws ChatException, RemoteException;
     void friendLoggedIn(User friend) throws ChatException,  RemoteException;
     void friendLoggedOut(User friend) throws ChatException,  RemoteException;
    
}
