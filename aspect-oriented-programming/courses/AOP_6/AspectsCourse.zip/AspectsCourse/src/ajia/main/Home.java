package ajia.main;
public class Home {
   public void enter() {
     System.out.println("Entering home");
   }
   public void exit() {
     System.out.println("Exiting home");
   }
}
