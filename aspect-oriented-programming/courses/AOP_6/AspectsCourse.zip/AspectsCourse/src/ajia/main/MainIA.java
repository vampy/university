package ajia.main;

public class MainIA {
	public static void main(String[] args) {
		MainIA main = new MainIA();
		main.perform();
	}
	public void perform() {
		System.out.println("<performing/>");
	}
}
