package ajia.main;

public class MainPrivilege {
	private int id;
	public static void main(String[] args) {
		MainPrivilege main = new MainPrivilege();
		main.method1(); 
	}
	public void method1() {  System.out.println("Main.method1");   }

}
