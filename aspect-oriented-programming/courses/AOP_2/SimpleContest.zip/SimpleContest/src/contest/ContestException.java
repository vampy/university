package contest;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Nov 25, 2008
 * Time: 3:33:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class ContestException extends Exception{
    public ContestException(){}
    public ContestException(String msg){
        super(msg);
    }
}
