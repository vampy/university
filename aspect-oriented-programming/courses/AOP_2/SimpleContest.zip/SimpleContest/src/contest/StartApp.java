package contest;

import contest.ctrl.ContestCtrl;
import contest.gui.ContestWindow;
import contest.gui.RankingWindow;
import contest.model.Contest;
import contest.repository.ParticipantRepository;
import contest.repository.jdbc.ParticipantsRepositoryJdbc;
import contest.repository.mock.ParticipantRepositoryMock;
import contest.ctrl.ViewResultsHandler;

import javax.swing.*;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Nov 24, 2011
 * Time: 1:05:16 AM
 */
public class StartApp {
    public static void main(String[] args) {
       // ParticipantRepository parts=new ParticipantRepositoryMock();

        Properties serverProps=new Properties(System.getProperties());
        try {
            serverProps.load(new FileReader("contestjdbc.properties"));
            System.setProperties(serverProps);

            System.out.println("Properties set: ");
            System.getProperties().list(System.out);
        } catch (IOException e) {
            System.out.println("Cannot find contestjdbc.properties "+e);
            return;
        }

        ParticipantRepository parts=new ParticipantsRepositoryJdbc();


        Contest concurs=new Contest(parts);
        final ContestCtrl ctrl=new ContestCtrl(concurs);
        SwingUtilities.invokeLater(new Runnable(){
            public void run() {
                ContestWindow cwin=new ContestWindow(ctrl);
                cwin.setSize(300,400);
                cwin.setLocation(150,150);
                cwin.setVisible(true);
            }
        });

       for(int i=0;i<1;i++){
            final ViewResultsHandler vrCtrl=new ViewResultsHandler(concurs);
            SwingUtilities.invokeLater(new Runnable(){
                public void run() {
                    RankingWindow cwin=new RankingWindow(vrCtrl);
                    cwin.setSize(300,300);
                    cwin.setLocation(175,175);
                    cwin.setVisible(true);
                }
            });
        }
        System.out.println("Started ...");

    }
}
