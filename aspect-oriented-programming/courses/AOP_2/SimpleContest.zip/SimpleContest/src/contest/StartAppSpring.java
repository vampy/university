package contest;

import contest.ctrl.ContestCtrl;
import contest.ctrl.ViewResultsHandler;
import contest.gui.ContestWindow;
import contest.gui.RankingWindow;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: 4/16/13
 * Time: 1:47 AM
 */
public class StartAppSpring {
    public static void main(String[] args) {
        System.out.println("Starting app with Spring");
        ApplicationContext factory=new ClassPathXmlApplicationContext("spring-contest.xml");
        final ContestCtrl ctrl= (ContestCtrl) factory.getBean("contestCtrl");
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                ContestWindow cwin = new ContestWindow(ctrl);
                cwin.setSize(300, 400);
                cwin.setLocation(150, 150);
                cwin.setVisible(true);
            }
        });
        for(int i=0;i<2;i++){
            final ViewResultsHandler vrCtrl= (ViewResultsHandler) factory.getBean("resultsHandler");
            SwingUtilities.invokeLater(new Runnable(){
                public void run() {
                    RankingWindow cwin=new RankingWindow(vrCtrl);
                    cwin.setSize(300,300);
                    cwin.setLocation(175,175);
                    cwin.setVisible(true);
                }
            });
        }
        System.out.println("Started ...");
    }
}
