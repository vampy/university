package contest.repository.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: 2/28/14
 * Time: 2:18 AM
 */
public class JdbcUtils {

    private static JdbcUtils instance=null;
    private Connection connection=null;
    private JdbcUtils(){

    }

    public static JdbcUtils getInstance(){
        if (instance==null)
            instance=new JdbcUtils();
        return instance;
    }

    private Connection getNewConnection(){
        String driver=System.getProperty("db.driver");
        String url=System.getProperty("db.url");
        String user=System.getProperty("db.user");
        String pass=System.getProperty("db.pass");
        Connection con=null;
        try {
            Class.forName(driver);
            System.out.println("Driver "+driver+" loaded");
            if ((user==null) || (pass==null))
                con= DriverManager.getConnection(url);
            else
                con= DriverManager.getConnection(url,user,pass);
        } catch (ClassNotFoundException e) {
            System.out.println("Error loading driver "+e);
        } catch (SQLException e) {
            System.out.println("Error getting connection "+e);
        }
        return con;
    }

    public Connection getConnection(){
        try {
            if (connection==null || connection.isClosed())
                connection=getNewConnection();

        } catch (SQLException e) {
            System.out.println("Error DB "+e);
        }
        return connection;
    }

}
