package contest.repository.jdbc;

import contest.model.Participant;
import contest.repository.ParticipantRepository;
import contest.repository.RepositoryException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: 2/28/14
 * Time: 2:15 AM
 */
public class ParticipantsRepositoryJdbc implements ParticipantRepository {
    public void save(Participant p) {
        System.out.println("ParticipantsJdbc:save");
        Connection con= JdbcUtils.getInstance().getConnection();
        PreparedStatement stmt=null;
        try {
            stmt=con.prepareStatement("insert into participants (id,name, points, tests) values (?,?,?,?)");
            stmt.setString(1, p.getID());
            stmt.setString(2, p.getName());
            stmt.setInt(3, p.getPoints());
            stmt.setInt(4, p.getTests());
            int s=stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RepositoryException("Error "+e);
        }finally {
            if (stmt!=null) try {
                stmt.close();
            } catch (SQLException e) {
                System.err.println("Error closing statement "+e);
            }
        }


    }


    public void update(String codePart, Participant p) {
        System.out.println("ParticipantsJdbc:update");
        Connection con= JdbcUtils.getInstance().getConnection();
        PreparedStatement stmt=null;
        try {
            stmt=con.prepareStatement("update participants set name=?, points=?, tests=? where id=?");
            stmt.setString(4, p.getID());
            stmt.setString(1, p.getName());
            stmt.setInt(2, p.getPoints());
            stmt.setInt(3, p.getTests());
            int s=stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RepositoryException("Error "+e);
        }finally {
            if (stmt!=null) try {
                stmt.close();
            } catch (SQLException e) {
                System.err.println("Error closing statement "+e);
            }
        }
    }

    public List<Participant> getAll() {
        System.out.println("ParticipantsJdbc:getAll");
        Connection con= JdbcUtils.getInstance().getConnection();
        List<Participant> rez=new ArrayList<Participant>();
        PreparedStatement stmt=null;
        try {
            stmt=con.prepareStatement("select id, name, points, tests from participants");
            ResultSet rs=stmt.executeQuery();

            while(rs.next()){
                String id = rs.getString("id");
                String nume = rs.getString("name");
                Participant p = new Participant(id, nume);
                int points = rs.getInt("points");
                int tests = rs.getInt("tests");
                p.setPoints(points);
                p.setTests(tests);
                rez.add(p);
            }


        } catch (SQLException e) {
            throw new RepositoryException("Error "+e);
        }finally {
            if (stmt!=null) try {
                stmt.close();
            } catch (SQLException e) {
                System.err.println("Error closing statement "+e);
            }
        }

        return rez;
    }

    public Participant findById(String code) {
        System.out.println("ParticipantsJdbc:findById");
        Connection con= JdbcUtils.getInstance().getConnection();
        Participant rez=null;
        PreparedStatement stmt=null;
        try {
            stmt=con.prepareStatement("select * from participants where id=?");
            stmt.setString(1,code);
            ResultSet rs=stmt.executeQuery();

            if(rs.next()){
                String id = rs.getString("id");
                String nume = rs.getString("name");
                rez= new Participant(id, nume);
                int points = rs.getInt("points");
                int tests = rs.getInt("tests");
                rez.setPoints(points);
                rez.setTests(tests);
            }
        } catch (SQLException e) {
            throw new RepositoryException("Error "+e);
        }finally {
            if (stmt!=null) try {
                stmt.close();
            } catch (SQLException e) {
                System.err.println("Error closing statement "+e);
            }
        }

        return rez;
    }

    public List<Participant> getByPoints() {
        System.out.println("ParticipantsJdbc:getByPoints");
        Connection con= JdbcUtils.getInstance().getConnection();
        List<Participant> rez=new ArrayList<Participant>();
        PreparedStatement stmt=null;
        try {
            stmt=con.prepareStatement("select id, name, points, tests from participants order by points desc");
            ResultSet rs=stmt.executeQuery();

            while(rs.next()){
                String id = rs.getString("id");
                String nume = rs.getString("name");
                Participant p = new Participant(id, nume);
                int points = rs.getInt("points");
                int tests = rs.getInt("tests");
                p.setPoints(points);
                p.setTests(tests);
                rez.add(p);
            }


        } catch (SQLException e) {
            throw new RepositoryException("Error "+e);
        }finally {
            if (stmt!=null) try {
                stmt.close();
            } catch (SQLException e) {
                System.err.println("Error closing statement "+e);
            }
        }

        return rez;
    }
}
