package contest.repository;



/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Oct 29, 2009
 * Time: 7:37:46 PM
 */
public class RepositoryException extends RuntimeException{
    public RepositoryException() {
    }

    public RepositoryException(String message) {
        super(message);
    }
    
}
