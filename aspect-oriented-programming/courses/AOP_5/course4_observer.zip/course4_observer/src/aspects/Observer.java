package aspects;

public interface Observer {
	public void update(Object data);

}
