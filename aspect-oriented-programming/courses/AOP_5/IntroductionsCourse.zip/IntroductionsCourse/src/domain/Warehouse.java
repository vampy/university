package domain;

public class Warehouse {
	private double space;
	public Warehouse(double space){
		this.space=space;
	}
	public double getSpace() {
		return space;
	}
}
