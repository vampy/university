package domain;
public class Customer /*implements Nameable*/{
	private String address;
	public Customer(){
		address="empty address";
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
