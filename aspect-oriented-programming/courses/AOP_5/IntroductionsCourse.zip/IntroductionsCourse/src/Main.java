import domain.Customer;
import domain.Warehouse;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//example Methods introductions
		/*Customer c1=new Customer();
		Customer c2=new Customer();
		System.out.println("c1.id= "+c1.getId());
		System.out.println("c2.id= "+c2.getId());
		Customer c3=new Customer();
		System.out.println("c3.id= "+c3.getId());*/
		
		//example Default interface implementation
		Customer c1=new Customer();
		c1.setName("Popescu Ion");
		System.out.println("c1.name= "+c1.getName());
		
		//example declare parents;
		Customer cp=new Customer();
		cp.setName("Popescu Maria");
		System.out.println("cp.id= "+cp.getId()+" cp.name= "+cp.getName());
		
		Warehouse wh=new Warehouse(23.0);
		wh.setName("Depozit 1, Cluj");
		System.out.println("wh.name "+wh.getName());
		
		
		
		
	}

}
