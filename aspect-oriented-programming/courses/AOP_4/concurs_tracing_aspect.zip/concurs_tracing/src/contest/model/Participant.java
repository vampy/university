package contest.model;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Nov 25, 2008
 * Time: 3:35:19 PM
 */
public class Participant {
    private String ID, name;
    private int tests, points;
    public Participant(String ID, String name){
        this.ID=ID;
        this.name = name;
        tests =0;
        points =0;
    }
    public String getName(){
        return name;
    }
    public String getID(){
        return ID;
    }
    public int getTests(){
        return tests;
    }
    public int getPoints(){
        return points;
    }

    public void adaugaRezultat(int puncte){
        this.points +=puncte;
        tests++;
    }



    public boolean equals(Object o){
        if (o instanceof Participant){
            Participant p=(Participant)o;
            return ID.equals(p.ID);
        }
        return false;
    }

    public String toString(){
        return ID+' '+ name +' '+ tests +' '+ points;
    }

    public static final String ID_FIELD = "id";
	public static final String NAME_FIELD = "name";
	public static final String POINTS_FIELD = "points";
    public static final String TESTS_FIELD = "tests";

    public void setTests(int tests) {
        this.tests =tests;
    }

    public void setPoints(int points) {
        this.points =points;
    }
}
