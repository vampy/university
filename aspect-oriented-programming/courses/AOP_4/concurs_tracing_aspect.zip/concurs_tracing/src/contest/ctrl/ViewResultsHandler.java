package contest.ctrl;

import contest.model.Contest;

import javax.swing.table.TableModel;
import java.util.Observer;
import java.util.Observable;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Dec 8, 2011
 * Time: 12:26:15 AM
 */
public class ViewResultsHandler implements Observer {
    private Contest concurs;
    private ParticipantsResTableModel partTM;
    public ViewResultsHandler(Contest concurs) {
        System.out.println("Results Handler constructor");
        this.concurs = concurs;
        partTM=new ParticipantsResTableModel(concurs.getParticipantsByPoints());
        concurs.addObserver(this);
    }

    public TableModel getParticipantiModel() {
          return partTM;
    }

    public void update(Observable o, Object arg) {
         partTM.setParticipanti(concurs.getParticipantsByPoints());
    }

    public void close() {
        concurs.deleteObserver(this);

    }
}
