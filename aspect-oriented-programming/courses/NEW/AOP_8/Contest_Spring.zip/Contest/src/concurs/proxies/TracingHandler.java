package concurs.proxies;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: 4/25/13
 * Time: 12:48 AM
 */
public class TracingHandler implements InvocationHandler {
    private Object target;
    	public TracingHandler(Object target) {
    		this.target = target;
    	}
    	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            System.out.println("Entering " + method);
    		return method.invoke(target, args); //similar to proceed
    	}
}
