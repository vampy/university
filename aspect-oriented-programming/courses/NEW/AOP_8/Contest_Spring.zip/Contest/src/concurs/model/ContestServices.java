package concurs.model;

import concurs.ConcursExceptie;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: 4/24/13
 * Time: 1:33 AM
 */
public interface ContestServices {
    public void adaugaRezultat(String ID, int puncte) throws ConcursExceptie;
    public void adaugaParticipant(String code, String nume) throws ConcursExceptie;
    public List<Participant> getParticipants();
    public List<Participant> getParticipantsByPoints();
    public Participant getParticipant(String idP) throws ConcursExceptie;
}
