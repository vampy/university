package concurs.repository.dao;

import concurs.model.Participant;
import concurs.repository.ParticipantRepository;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: 4/16/13
 * Time: 1:57 AM
 */
public class ParticipantsRepositoryDAO extends JdbcDaoSupport implements ParticipantRepository {
    public ParticipantsRepositoryDAO() {
        System.out.println("ParticipantsDAO constructor");
    }

    public void save(Participant p) {
        getJdbcTemplate().update("insert into participants (id,name, points, tests) " +
                "values (?,?,?,?)", p.getID(), p.getNume(), p.getPunctaj(), p.getNrProbe());

    }

    public void update(String codePart, Participant p) {
        getJdbcTemplate().update("update participants set name=?, points=?, tests=? where id=?", p.getNume(), p.getPunctaj(), p.getNrProbe(), codePart);

    }

    public List<Participant> getAll() {
        List<Participant> res = getJdbcTemplate().query("select id, name, points, tests from participants", new PartMapper());
        return res;
    }

    public Participant findById(String code) {
        Participant p=getJdbcTemplate().queryForObject("select * from participants where id=?", new PartMapper(),code);
        return p;
    }

    public List<Participant> getByPoints() {
        List<Participant> res = getJdbcTemplate().query("select id, name, points, tests from participants order by points desc", new PartMapper());
        return res;
    }

    private static class PartMapper implements RowMapper<Participant> {
        public Participant mapRow(ResultSet rs, int rowNum) throws SQLException {
            String id = rs.getString("id");
            String nume = rs.getString("name");
            Participant p = new Participant(id, nume);
            int points = rs.getInt("points");
            int tests = rs.getInt("tests");
            p.setPoints(points);
            p.setTests(tests);
            return p;
        }
    }
}
