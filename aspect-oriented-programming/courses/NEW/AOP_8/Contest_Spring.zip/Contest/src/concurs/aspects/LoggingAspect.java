package concurs.aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

import java.util.logging.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: 4/24/13
 * Time: 1:19 AM
 */
@Aspect
public class LoggingAspect {
    @Pointcut("execution(public * concurs.repository..*(..))&& !within(LoggingAspect)")
    public void tracing(){}

    private Logger logger= Logger.getLogger("contest");

    @Before("tracing()")
    public void trace(JoinPoint jp){
        logger.info("Entering: "+jp.getSignature());
        //System.out.println("Entering method: "+thisJoinPointStaticPart.getSignature());
    }


    @After("tracing()")
    public void afterTrace(JoinPoint jp){
        //printIndentation();
        //System.out.println("Exiting method: "+thisJoinPointStaticPart.getSignature());
        logger.info("Exiting: "+jp.getSignature());
        //indentation--;

    }


}
