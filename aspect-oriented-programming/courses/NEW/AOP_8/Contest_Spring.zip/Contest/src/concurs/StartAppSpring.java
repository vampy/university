package concurs;

import concurs.ctrl.ConcursCtrl;
import concurs.ctrl.ViewResultsHandler;
import concurs.gui.ClasamentWindow;
import concurs.gui.ConcursWindow;
import concurs.model.Concurs;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: 4/16/13
 * Time: 1:47 AM
 */
public class StartAppSpring {
    public static void main(String[] args) {

        ApplicationContext factory=new ClassPathXmlApplicationContext("spring-contest.xml");
        final ConcursCtrl ctrl= (ConcursCtrl) factory.getBean("contestCtrl");
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                ConcursWindow cwin = new ConcursWindow(ctrl);
                cwin.setSize(300, 400);
                cwin.setLocation(150, 150);
                cwin.setVisible(true);
            }
        });
        for(int i=0;i<2;i++){
            final ViewResultsHandler vrCtrl= (ViewResultsHandler) factory.getBean("resultsHandler");
            SwingUtilities.invokeLater(new Runnable(){
                public void run() {
                    ClasamentWindow cwin=new ClasamentWindow(vrCtrl);
                    cwin.setSize(300,300);
                    cwin.setLocation(175,175);
                    cwin.setVisible(true);
                }
            });
        }
        System.out.println("Started with Spring ...");
    }
}
