package concurs.proxies;

import concurs.repository.ParticipantRepository;
import concurs.repository.dao.ParticipantsRepositoryDAO;
import concurs.repository.mock.ParticipantRepositoryMock;

import java.lang.reflect.Proxy;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: 4/25/13
 * Time: 12:50 AM
 */
public class TestProxy {
    public static void main(String[] args) {
        ParticipantRepository participantRepository = new ParticipantRepositoryMock();
        ParticipantRepository participantRepositoryProxy = (ParticipantRepository)
                Proxy.newProxyInstance(ParticipantRepository.class.getClassLoader(), new Class[]{ParticipantRepository.class},
                        new TracingHandler(participantRepository));
        System.out.println(participantRepositoryProxy.findById("123"));

        System.out.println(participantRepositoryProxy.getByPoints());

    }
}


