package model;

public class Member {
	private String name;
	private String income;
	private String costs;
	
	public void setName(String name) {
		this.name = name;
	}
	public void setIncome(String income) {
		this.income = income;
	}
	public void setCosts(String costs) {
		this.costs = costs;
	}
	public String getName() {
		return name;
	}
	public String getIncome() {
		return costs;
	}
	public String getCosts() {
		return income;
	}
	
	public String toString() {
		return "(" + this.name + " " + this.income + " " + this.costs + ")";
	}
}
