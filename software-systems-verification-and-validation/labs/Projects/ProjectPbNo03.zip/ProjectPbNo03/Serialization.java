
package persistency;
import java.io.*;
import model.ClientDB;
public class Serialization {
    public static ClientDB DeSerialize() {
        //Get serialized info and add it to ChocolateDB
        ClientDB pDetails = null;
        FileInputStream fis = null;
        ObjectInputStream in = null;
        try {
            fis = new FileInputStream("data.bin");
            in = new ObjectInputStream(fis);
            pDetails = (ClientDB) in.readObject();
            in.close();
            fis.close();
        } catch (EOFException ex) {
            FileOutputStream fos = null;
            ObjectOutputStream out = null;
            try {
                try {
                    fos = new FileOutputStream("data.bin");
                } catch(FileNotFoundException e) {
                    //do nothing
                }
                out = new ObjectOutputStream(fos);
                out.writeObject(new ClientDB());
                out.close();
                fos.close();
            } catch (IOException e) {
                //do nothing
            }
        } catch (IOException ex) {
            //do nothing
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return pDetails;
    }
    
    public static boolean Serialize(ClientDB choc) {
        //Serialize all info from ChocolateDB
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
        try {
            fos = new FileOutputStream("data.bin");
            out = new ObjectOutputStream(fos);
            out.writeObject(choc);
            out.close();
            fos.close();
            return true;
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }
}
