package model;

import java.io.Serializable;
public class Client implements Serializable {
    String name;
    String address;

    public Client(String name, String address) {
        this.name = name;
        this.address = address;
    }
    
    public Client() {
        this.name = "";
        this.address = "";
    }

    public String getName() {
        return address;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
