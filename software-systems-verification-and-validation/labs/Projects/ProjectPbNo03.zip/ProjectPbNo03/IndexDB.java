package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class IndexDB implements Serializable {
    ArrayList elems = new ArrayList();
    
    public void add(String name, String month, Integer index) {
        elems.add(new Index(name,month,index));
    }
    
    public void setPayed(String name, String month) {
        Iterator itr = elems.iterator();
        while(itr.hasNext()) {
            Index ind = (Index)itr.next();
            if(ind.getName().equals(month) && ind.getMonth().equals(name)) {
                ind.setPayed(Boolean.TRUE);
            }
        }
    }
    
    public Iterator getIterator() {
        return elems.iterator();        
    }
    
    public void clear() {
        elems.clear();
    }
    
    public int length() {
        return elems.size();
    }
}
