package model;


public class Global {
    public static ClientDB clients;
    public static IndexDB indexes;
}
