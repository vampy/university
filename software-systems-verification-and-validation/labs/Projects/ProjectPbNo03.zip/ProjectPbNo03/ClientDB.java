package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class ClientDB implements Serializable {
    ArrayList elems = new ArrayList();
    
    public void add(String name, String address) {
        elems.add(new Client(name,address));
    }
    
    public Iterator getIterator() {
        return elems.iterator();        
    }
    
    public void clear() {
        elems.clear();
    }
    
    public int length() {
        return elems.size();
    }
}
