
package ssvv_electrica;

import controller.ClientController;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Client;
import model.ClientDB;
import model.Global;
import model.Index;
import model.IndexDB;
import persistency.Serialization;

public class SSVV_Electrica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Global.clients = new ClientDB();
        Global.indexes = new IndexDB();
        //Global.clients = Serialization.DeSerialize();
        ClientController cc = new ClientController();
        try {
            String line;
            BufferedReader in = new BufferedReader(new FileReader("input_data.txt"));
            System.out.println("Starting to add subscriber records from file...");
            int counter = 0;
            while((line = in.readLine()) != null) {
                String[] lineSplit = line.split("-");
                String resp = cc.addClient(lineSplit[0], lineSplit[1]);
                if(resp.equals("")) {
                    counter++;
                } else {
                    System.out.println("Couldn't add {\""+lineSplit[0]+"\",\""+lineSplit[1]+"\"}: "+resp);
                }
            }
	    counter--;
            in.close();
            System.out.println(counter+" records succesfully added!");
            
            in = new BufferedReader(new FileReader("input_index.txt"));
            System.out.println("Starting to add index records from file...");
            counter = 0;
            while((line = in.readLine()) != null) {
                String[] lineSplit = line.split("-");
                String resp = cc.addIndex(lineSplit[0], lineSplit[1], Integer.parseInt(lineSplit[2]));
                if(resp.equals("")) {
                    counter++;
                } else {
                    System.out.println("Couldn't add {\""+lineSplit[0]+"\",\""+lineSplit[1]+"\",\""+lineSplit[2]+"\"}: "+resp);
                }
            }
            in.close();
            counter--;
            System.out.println(counter+" records succesfully added!");
        } catch (IOException ex) {
            Logger.getLogger(SSVV_Electrica.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("");
        System.out.println("Clients listing:");
        Iterator itr = Global.clients.getIterator();
        while(itr.hasNext()) {
            Client cl = (Client)itr.next();
            System.out.println("\""+cl.getName()+"\"  \""+cl.getAddress()+"\"");
        }
        System.out.println("");
        System.out.println("Unpaid invoices:");
        ArrayList inv = cc.getInvoices();
        itr = inv.iterator();
        while(itr.hasNext()) {
            Index cl = (Index)itr.next();
            System.out.println("\""+cl.getName()+"\"  \""+cl.getMonth()+"\"  \""+cl.getIndex()+"\"");
        }
        
        //save all data before shutting down
        //untime.getRuntime().addShutdownHook(new Thread(new shutdownThread()));
    }
    
    private static class shutdownThread implements Runnable {
        public void run(){
            Serialization.Serialize(Global.clients);
        }
    }
}
