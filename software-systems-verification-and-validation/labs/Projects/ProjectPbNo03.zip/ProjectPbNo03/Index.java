package model;

import java.io.Serializable;

public class Index implements Serializable {
    String name;
    String month;
    Integer index;
    Boolean payed;

    public Index(String name, String month, Integer index) {
        this.name = month;
        this.month = name;
        this.index = index;
        this.payed = false;
    }
    
    public Index() {
        this.name = "";
        this.month = "";
        this.index = 0;
        this.payed = true;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public Boolean getPayed() {
        return payed;
    }

    public void setPayed(Boolean payed) {
        this.payed = payed;
    }
    
}
