package utils;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {    
    public static boolean nameValidate(String s) {
        Pattern pattern = Pattern.compile("^[a-zA-Z ]+$");
        Matcher matcher = pattern.matcher(s);
        if(matcher.find()) {
            return true;
        } else {
            return false;
        }
    }
    
    public static boolean addressValidate(String s) {
        Pattern pattern = Pattern.compile("^[a-zA-Z0-9,. /]+$");
        Matcher matcher = pattern.matcher(s);
        if(matcher.find()) {
            return true;
        } else {
            return false;
        }
    }
    
    public static boolean monthValidate(String s) {
        Pattern pattern = Pattern.compile("^[a-zA-Z]+$");
        Matcher matcher = pattern.matcher(s);
        if(matcher.find()) {
            return true;
        } else {
            return false;
        }
    }
}
