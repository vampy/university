package controller;

import java.util.ArrayList;
import java.util.Iterator;
import model.Client;
import model.ClientDB;
import model.Global;
import model.Index;
import model.IndexDB;
import utils.Validation;

public class ClientController {
    ClientDB clients = Global.clients;
    IndexDB indexes = Global.indexes;
    
    public String addClient(String name, String address) {
        //check if not empty
        if(name.length() > 0 && address.length() > 0) {
            //validate input
            if(Validation.nameValidate(address)) {
                if(Validation.addressValidate(name)) {
                    //add to clients
                    clients.add(address, name);
                    return "";
                } else {
                    return "The \"address\" field has an invalid format!";
                }
            } else {
                return "The \"name\" field has an invalid format!";
            }
        } else {
            return "One of the required fields is empty!";
        }
    }
    
    public String addIndex(String name, String month, Integer index) {
        //check if not empty
        if(name.length() > 0 && month.length() > 0 || index > 0) {
            //validate input
            if(Validation.nameValidate(name)) {
                if(Validation.monthValidate(month)) {
                    //check if name exists
                    boolean ok = false;
                    Iterator itr = clients.getIterator();
                    while(itr.hasNext()) {
                        Client cl = (Client)itr.next();
                        if(cl.getName().equals(name)) {
                            ok = true;
                        }
                    }
                    if(ok) {
                        //add the index
                        indexes.add(name, month, index);
                        return "";
                    } else {
                        return "The subscriber you have entered does not exist!";
                    }
                } else {
                    return "The \"month\" field has an invalid format!";
                }
            } else {
                return "The \"name\" field has an invalid format!";
            }
        } else {
            return "One of the required fields is empty!";
        }
    }
    
    public ArrayList getInvoices() {
        ArrayList elems = new ArrayList();
        Iterator itr = indexes.getIterator();
        while(itr.hasNext()) {
            Index ind = (Index)itr.next();
            if(ind.getPayed() == Boolean.FALSE) {
                elems.add(ind);
            }
        }
        return elems;
    }
}
