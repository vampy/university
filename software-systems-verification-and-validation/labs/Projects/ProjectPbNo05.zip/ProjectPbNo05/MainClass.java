package mainPackage;

import java.io.IOException;
import java.util.ArrayList;

import model.Product;
import controller.Ctrl;

public class MainClass {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		Product p=new Product();
		//p.read();
		Ctrl c=new Ctrl();
		c.readProducts("products.txt");
		//c.addProduct(p);
	//	for(Product q:c.getProductsCategory("second")){
		//	System.out.println(q.toString());
		//}
		for(Product q:c.stockSituationProduct("Laptop"))
			System.out.println(q.toString());
		
	}

}
