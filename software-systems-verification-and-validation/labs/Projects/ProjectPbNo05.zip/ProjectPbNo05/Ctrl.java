package controller;

import java.io.IOException;
import java.util.ArrayList;

import persistence.FileIO;
import model.Product;

public class Ctrl { 
	FileIO io =new FileIO();	
	public void readProducts(String f){
		try {
			io.readFile(f);
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void addProduct(Product p){
		try {

			io.addNewProduct(p);
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	}
	public ArrayList<Product> getProductsCategory(String cat){
		return io.getProductsCategory(cat);
	}
	
	public ArrayList<Product> stockSituationProduct(String pname){
		return io.stockSituationProduct(pname);
	}
	public ArrayList<Product> stockSituation(){
		return io.stockSituation();
	}
}
