﻿Public Class WebForm2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Response.Write("Hello .Net World!")
        div1.InnerText = "exemplu cu " & "code " & "behind"
    End Sub

End Class