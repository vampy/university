﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using MySql.Data.MySqlClient;


namespace WebApplication2
{
    public partial class ExBazadeDateNETConnectorCuCodeBehind : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            MySql.Data.MySqlClient.MySqlConnection conn;
            string myConnectionString;

            myConnectionString = "server=localhost;uid=root;pwd=;database=forest;";

            try
            {
                conn = new MySql.Data.MySqlClient.MySqlConnection();
                conn.ConnectionString = myConnectionString;
                conn.Open();

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "select * from studenti";
                MySqlDataReader myreader = cmd.ExecuteReader();

                div2.InnerHtml = "<table>";
                while (myreader.Read())
                {
                    div2.InnerHtml += "<tr>" + "<td>" + myreader.GetInt32(0) + "</td>" +
                        "<td>" + myreader.GetInt32(1) + "</td>" + "<td>" + myreader.GetString(2) + "</td>" + "</tr>";
                }
                div2.InnerHtml += "</table>";
                myreader.Close();

                // punem grupele in Listbox1
                //ListBox1.Items.Clear();
                if (!IsPostBack)
                {
                    cmd.CommandText = "select distinct(nume) from grupe";
                    myreader = cmd.ExecuteReader();

                    while (myreader.Read())
                    {
                        ListBox1.Items.Add(new ListItem(myreader.GetInt32(0) + ""));
                    }
                    myreader.Close();
                }

                conn.Close();

            }
            catch (MySql.Data.MySqlClient.MySqlException ex)
            {

                Response.Write(ex.Message);
            }
        }

        protected void AddBtn_Click(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                MySql.Data.MySqlClient.MySqlConnection conn;
                string myConnectionString;
                myConnectionString = "server=localhost;uid=root;pwd=;database=forest;";
                try
                {
                    conn = new MySql.Data.MySqlClient.MySqlConnection();
                    conn.ConnectionString = myConnectionString;
                    conn.Open();

                    MySqlCommand cmd = new MySqlCommand();
                    cmd.Connection = conn;
                    string id = TextBox1.Text;
                    string grupa = ListBox1.SelectedItem.Text;
                    string nume = TextBox2.Text;
                    if ((id != null) && (grupa != null) && (nume != null))
                    {
                        cmd.CommandText = "insert into studenti values('" + id + "'," + grupa + ",'" + nume + "')";
                        cmd.ExecuteNonQuery();
                    }
                    conn.Close();
                    Label1.Text = "Am adaugat studentul " + TextBox2.Text;
                }
                catch (MySql.Data.MySqlClient.MySqlException ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }
    }
}